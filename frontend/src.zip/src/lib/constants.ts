// Prazos máximos de inspeção por categoria (NR-13 tabela 13.4.4.4)
export const PRAZOS_NR13: Record<string, { ext: string; int: string; hid: string }> = {
  I:   { ext: '40 anos', int: '40 anos', hid: '40 anos' },
  II:  { ext: '12 anos', int: '12 anos', hid: '20 anos' },
  III: { ext: '8 anos',  int: '8 anos',  hid: '20 anos' },
  IV:  { ext: '4 anos',  int: '8 anos',  hid: '20 anos' },
  V:   { ext: '2 anos',  int: '4 anos',  hid: '10 anos' },
};

// Classes de fluido NR-13
export const CLASSES_FLUIDO = [
  { value: 'A', label: 'Classe A – Inflamável / Tóxico grave' },
  { value: 'B', label: 'Classe B – Inflamável / Tóxico moderado' },
  { value: 'C', label: 'Classe C – Vapor d\'água / Gás asfixiante / Ar' },
];

// Tipos de equipamento
export const TIPOS_EQUIPAMENTO = [
  'Vaso de Pressão',
  'Caldeira',
  'Vaso criogênico',
  'Tanque metálico de armazenamento',
  'Tubulação de interligação',
];

// Tipos de inspeção
export const TIPOS_INSPECAO = ['Externa', 'Interna', 'Interna e Externa'];

// Resultados de inspeção
export const RESULTADOS_INSPECAO = ['Apto', 'Inapto', 'Apto com restrições'];

// Fluidos comuns
export const FLUIDOS_COMUNS = [
  'Ar comprimido',
  'Vapor d\'água',
  'Nitrogênio',
  'CO2',
  'GLP',
  'Óleo combustível',
  'Água quente',
  'Amônia',
  'Outro',
];

// Normas de referência para ME
export const NORMAS_ME = [
  'Petrobras N-1594 | ASME VIII Div.1',
  'ABNT NBR 15248',
  'ASME V',
  'AWS D1.1',
];

// Códigos de projeto comuns
export const CODIGOS_PROJETO = [
  'ASME VIII Div.1 Ed 2017',
  'ASME VIII Div.1 Ed 2021',
  'ASME VIII Div.2',
  'ABNT NBR 13523',
  'EN 13445',
  'PD 5500',
];
