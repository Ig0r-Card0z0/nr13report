import axios from 'axios';

const api = axios.create({
  baseURL: typeof window !== 'undefined'
    ? '/api'
    : `${process.env.NEXT_PUBLIC_API_URL || 'http://localhost:3001'}/api`,
  timeout: 30000,
});

// Interceptor para extrair data do envelope { success, data, timestamp }
api.interceptors.response.use(
  res => {
    if (res.data && typeof res.data === 'object' && 'success' in res.data && 'data' in res.data) {
      return { ...res, data: res.data.data };
    }
    return res;
  },
  err => Promise.reject(err)
);

// ── Dashboard ─────────────────────────────────────────
export const dashboardApi = {
  stats:       ()           => api.get('/dashboard/stats').then(r => r.data),
  vencimentos: (dias = 90)  => api.get('/dashboard/vencimentos', { params: { dias } }).then(r => r.data),
  recentes:    ()           => api.get('/dashboard/recentes').then(r => r.data),
};

// ── Clientes ──────────────────────────────────────────
export const clientesApi = {
  listar:     ()                    => api.get('/clientes').then(r => r.data),
  buscar:     (id: string)          => api.get(`/clientes/${id}`).then(r => r.data),
  criar:      (data: any)           => api.post('/clientes', data).then(r => r.data),
  atualizar:  (id: string, d: any)  => api.patch(`/clientes/${id}`, d).then(r => r.data),
  excluir:    (id: string)          => api.delete(`/clientes/${id}`).then(r => r.data),
};

// ── Equipamentos ──────────────────────────────────────
export const equipamentosApi = {
  listar:     (clienteId?: string)  => api.get('/equipamentos', { params: { clienteId } }).then(r => r.data),
  buscar:     (id: string)          => api.get(`/equipamentos/${id}`).then(r => r.data),
  vencimentos:(dias = 90)           => api.get('/equipamentos/vencimentos', { params: { dias } }).then(r => r.data),
  criar:      (data: any)           => api.post('/equipamentos', data).then(r => r.data),
  atualizar:  (id: string, d: any)  => api.patch(`/equipamentos/${id}`, d).then(r => r.data),
  excluir:    (id: string)          => api.delete(`/equipamentos/${id}`).then(r => r.data),
};

// ── Inspeções ─────────────────────────────────────────
export const inspecoesApi = {
  listar: (equipamentoId: string)   => api.get('/inspecoes', { params: { equipamentoId } }).then(r => r.data),
  criar:  (data: any)               => api.post('/inspecoes', data).then(r => r.data),
  excluir:(id: string)              => api.delete(`/inspecoes/${id}`).then(r => r.data),
};

// ── Fotos ─────────────────────────────────────────────
export const fotosApi = {
  listar: (equipamentoId: string)       => api.get('/fotos', { params: { equipamentoId } }).then(r => r.data),
  upload: (formData: FormData)          => api.post('/fotos/upload', formData, {
    headers: { 'Content-Type': 'multipart/form-data' },
  }).then(r => r.data),
  legenda:(id: string, legenda: string) => api.patch(`/fotos/${id}/legenda`, { legenda }).then(r => r.data),
  excluir:(id: string)                  => api.delete(`/fotos/${id}`).then(r => r.data),
};

// ── Medição Espessura ─────────────────────────────────
export const meApi = {
  listar: (equipamentoId: string)   => api.get('/me', { params: { equipamentoId } }).then(r => r.data),
  salvar: (data: any)               => api.post('/me', data).then(r => r.data),
  excluir:(id: string)              => api.delete(`/me/${id}`).then(r => r.data),
};

// ── Relatórios ────────────────────────────────────────
export const relatoriosApi = {
  urlPDF: (equipamentoId: string)   => `/api/relatorios/pdf/${equipamentoId}`,
};

// ── Health ────────────────────────────────────────────
export const healthApi = {
  check: () => api.get('/health', { baseURL: typeof window !== 'undefined' ? '' : process.env.NEXT_PUBLIC_API_URL || 'http://localhost:3001' }).then(r => r.data),
};

export default api;
