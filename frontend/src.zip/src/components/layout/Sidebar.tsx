'use client';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { LayoutDashboard, Users, PlusCircle, Archive, FileText, Download } from 'lucide-react';
import clsx from 'clsx';

const nav = [
  { label: 'Painel', href: '/', icon: LayoutDashboard },
  { label: 'Clientes', href: '/clientes', icon: Users },
  { label: 'Novo cliente', href: '/clientes/novo', icon: PlusCircle },
  { label: 'Equipamentos', href: '/equipamentos', icon: Archive },
  { label: 'Novo equipamento', href: '/equipamentos/novo', icon: PlusCircle },
];

export function Sidebar() {
  const path = usePathname();
  return (
    <aside className="w-56 bg-white border-r border-gray-200 flex flex-col flex-shrink-0 h-screen">
      <div className="p-5 border-b border-gray-200">
        <div className="text-base font-bold text-primary-700">NR-13</div>
        <div className="text-xs text-gray-500 mt-0.5">Gestão de Inspeções</div>
      </div>
      <nav className="flex-1 p-3 overflow-y-auto">
        <div className="text-xs font-semibold text-gray-400 uppercase tracking-wider px-2 mb-2">Sistema</div>
        {nav.map(({ label, href, icon: Icon }) => (
          <Link key={href} href={href}
            className={clsx(
              'flex items-center gap-3 px-3 py-2 rounded-lg text-sm mb-1 transition-colors',
              path === href
                ? 'bg-primary-50 text-primary-700 font-semibold'
                : 'text-gray-600 hover:bg-gray-100 hover:text-gray-900'
            )}>
            <Icon size={15} />
            {label}
          </Link>
        ))}
      </nav>
      <div className="p-3 border-t border-gray-200">
        <div className="text-xs text-gray-400 px-2">Portaria SEPRT nº 915/2019</div>
      </div>
    </aside>
  );
}
