'use client';
import { useEffect, useState } from 'react';
import { meApi } from '@/lib/api';
import { MedicaoEspessura, PontoMe } from '@/types';
import toast from 'react-hot-toast';
import { Plus, Trash2 } from 'lucide-react';
import { calcReducao } from '@/lib/utils';
import clsx from 'clsx';

interface Props { equipamentoId: string; inspecaoId?: string; metalBase?: string; onSaved?: () => void; }

export function MedicaoEspessuraForm({ equipamentoId, inspecaoId, metalBase, onSaved }: Props) {
  const [medicao, setMedicao] = useState<MedicaoEspessura | null>(null);
  const [saving, setSaving] = useState(false);
  const [dados, setDados] = useState({
    dataEnsaio: '', norma: 'Petrobras N-1594 | ASME VIII Div.1', procedimento: '',
    equipamentoMed: '', cabecote: '', acoplante: 'Gel',
    certCalibracao: '', dataCalibracao: '', validadeCalibracao: '',
    metalBase: metalBase || '', condicaoSuperficial: 'Limpa/Escovada',
    temperaturaPeca: '', inspetor: '', conclusao: '',
  });
  const [pontos, setPontos] = useState<Partial<PontoMe>[]>([]);

  const load = () => meApi.listar(equipamentoId).then(r => {
    if (r[0]) {
      const m: MedicaoEspessura = r[0];
      setMedicao(m);
      setDados({
        dataEnsaio: m.data_ensaio || '', norma: m.norma || '',
        procedimento: m.procedimento || '', equipamentoMed: m.equipamento_med || '',
        cabecote: m.cabecote || '', acoplante: m.acoplante || '',
        certCalibracao: m.cert_calibracao || '', dataCalibracao: m.data_calibracao || '',
        validadeCalibracao: m.validade_calibracao || '', metalBase: m.metal_base || metalBase || '',
        condicaoSuperficial: m.condicao_superficial || '',
        temperaturaPeca: m.temperatura_peca?.toString() || '', inspetor: m.inspetor || '',
        conclusao: m.conclusao || '',
      });
      setPontos(m.pontos || []);
    }
  });

  useEffect(() => { load(); }, [equipamentoId]);

  const setD = (k: string) => (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) =>
    setDados(d => ({ ...d, [k]: e.target.value }));

  const addPonto = () => setPontos(p => [...p, {
    numero: `P${p.length + 1}`, regiao: '',
    espessura_nominal: undefined, espessura_encontrada: undefined, espessura_minima: undefined,
  }]);

  const removePonto = (i: number) => setPontos(p =>
    p.filter((_, j) => j !== i).map((x, j) => ({ ...x, numero: `P${j + 1}` })));

  const setP = (i: number, k: string) => (e: React.ChangeEvent<HTMLInputElement>) =>
    setPontos(p => p.map((x, j) => j === i ? { ...x, [k]: e.target.value ? parseFloat(e.target.value) : undefined } : x));

  const setPStr = (i: number, k: string) => (e: React.ChangeEvent<HTMLInputElement>) =>
    setPontos(p => p.map((x, j) => j === i ? { ...x, [k]: e.target.value } : x));

  const salvar = async () => {
    setSaving(true);
    try {
      await meApi.salvar({
        equipamentoId, inspecaoId,
        ...dados,
        temperaturaPeca: dados.temperaturaPeca ? parseFloat(dados.temperaturaPeca) : undefined,
        pontos: pontos.map(p => ({
          numero: p.numero || '',
          regiao: p.regiao,
          espessuraNominal: p.espessura_nominal,
          espessuraEncontrada: p.espessura_encontrada,
          espessuraMinima: p.espessura_minima,
        })),
      });
      toast.success('Medição de espessura salva!');
      load();
    } catch (err: any) {
      const msg = err?.response?.data?.message || err?.message || 'Erro ao salvar.';
      toast.error(String(msg));
    } finally { setSaving(false); }
  };

  const getStatus = (p: Partial<PontoMe>) => {
    const enc = p.espessura_encontrada, nom = p.espessura_nominal, min = p.espessura_minima;
    if (!enc) return null;
    if (min && enc < min) return 'critico';
    if (nom && enc < nom * 0.9) return 'atencao';
    return 'ok';
  };

  const critCount = pontos.filter(p => getStatus(p) === 'critico').length;
  const encValues = pontos.map(p => p.espessura_encontrada).filter((v): v is number => v !== undefined && v > 0);

  return (
    <div>
      {/* Resumo estatístico */}
      {encValues.length > 0 && (
        <div className="grid grid-cols-4 gap-3 mb-5">
          {[
            { label: 'Pontos medidos', val: encValues.length, color: '' },
            { label: 'Menor espessura', val: `${Math.min(...encValues).toFixed(2)} mm`, color: critCount > 0 ? 'text-red-600' : '' },
            { label: 'Maior espessura', val: `${Math.max(...encValues).toFixed(2)} mm`, color: '' },
            { label: 'Pontos críticos', val: critCount, color: critCount > 0 ? 'text-red-600 font-bold' : 'text-green-600' },
          ].map(({ label, val, color }) => (
            <div key={label} className="bg-gray-50 border border-gray-200 rounded-lg p-3">
              <div className="text-xs text-gray-500">{label}</div>
              <div className={clsx('text-lg font-bold mt-1', color || 'text-gray-900')}>{val}</div>
            </div>
          ))}
        </div>
      )}

      {/* Dados do ensaio */}
      <div className="bg-white border border-gray-200 rounded-xl p-5 mb-4">
        <h3 className="text-sm font-semibold text-gray-700 mb-4">Dados do ensaio</h3>
        <div className="grid grid-cols-3 gap-3">
          {[
            ['Data do ensaio', 'dataEnsaio', 'date'], ['Inspetor END', 'inspetor', 'text'],
            ['Norma de referência', 'norma', 'text'], ['Procedimento / Rev.', 'procedimento', 'text'],
            ['Equipamento de medição', 'equipamentoMed', 'text'], ['Cabeçote', 'cabecote', 'text'],
            ['Acoplante', 'acoplante', 'text'], ['Cert. calibração', 'certCalibracao', 'text'],
            ['Data calibração', 'dataCalibracao', 'date'], ['Validade calibração', 'validadeCalibracao', 'date'],
            ['Metal de base', 'metalBase', 'text'], ['Condição superficial', 'condicaoSuperficial', 'text'],
            ['Temperatura da peça (°C)', 'temperaturaPeca', 'number'],
          ].map(([label, key, type]) => (
            <div key={key}>
              <label className="label">{label}</label>
              <input className="input" type={type} value={(dados as any)[key]} onChange={setD(key)} />
            </div>
          ))}
        </div>
      </div>

      {/* Tabela de pontos */}
      <div className="bg-white border border-gray-200 rounded-xl p-5 mb-4">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-sm font-semibold text-gray-700">Tabela de pontos de medição</h3>
          <button onClick={addPonto} className="btn btn-primary btn-sm"><Plus size={13} /> Ponto</button>
        </div>

        {pontos.length === 0 ? (
          <div className="text-center py-6 text-gray-300 text-sm border-2 border-dashed border-gray-200 rounded-lg">
            Nenhum ponto. Clique em "+ Ponto" para adicionar.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm border-collapse">
              <thead>
                <tr className="bg-gray-50">
                  {['Ponto', 'Região / Descrição', 'E. Nominal (mm)', 'E. Encontrada (mm)', 'E. Mínima (mm)', 'Redução', 'Status', ''].map(h => (
                    <th key={h} className="text-left text-xs font-semibold text-gray-500 uppercase tracking-wide px-2 py-2 border-b border-gray-200">
                      {h}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {pontos.map((p, i) => {
                  const red = calcReducao(p.espessura_nominal, p.espessura_encontrada);
                  const st = getStatus(p);
                  return (
                    <tr key={i} className={clsx('border-b border-gray-100 transition-colors',
                      st === 'critico' ? 'bg-red-50' : st === 'atencao' ? 'bg-yellow-50' : '')}>
                      <td className="px-2 py-1.5 font-bold text-gray-700 w-16">{p.numero}</td>
                      <td className="px-2 py-1.5">
                        <input className="input py-1 text-xs w-36"
                          value={p.regiao || ''} onChange={setPStr(i, 'regiao')} placeholder="Ex: Casco sup." />
                      </td>
                      {[
                        ['espessura_nominal', 'E. nom.'],
                        ['espessura_encontrada', 'E. enc.'],
                        ['espessura_minima', 'E. mín.'],
                      ].map(([k, ph]) => (
                        <td key={k} className="px-2 py-1.5 w-28">
                          <input className="input py-1 text-xs text-center"
                            type="number" step="0.01" placeholder="0.00"
                            value={(p as any)[k] ?? ''} onChange={setP(i, k)} />
                        </td>
                      ))}
                      <td className="px-2 py-1.5 text-center text-xs font-semibold w-20">
                        {red !== null ? `${red}%` : '—'}
                      </td>
                      <td className="px-2 py-1.5 text-center w-20">
                        {st === 'critico' && <span className="badge badge-danger">Crítico</span>}
                        {st === 'atencao' && <span className="badge badge-warning">Atenção</span>}
                        {st === 'ok'      && <span className="badge badge-success">OK</span>}
                        {st === null      && <span className="text-gray-300 text-xs">—</span>}
                      </td>
                      <td className="px-2 py-1.5 w-10">
                        <button onClick={() => removePonto(i)} className="btn btn-xs btn-danger">
                          <Trash2 size={11} />
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}

        <div className="mt-4">
          <label className="label">Conclusão do ensaio</label>
          <textarea className="input" rows={3} value={dados.conclusao} onChange={setD('conclusao')}
            placeholder="Ex: Não foram detectadas reduções significativas de espessura. O equipamento está apto para operação na PMTA indicada." />
        </div>
      </div>

      <div className="flex justify-end">
        <button onClick={salvar} disabled={saving} className="btn btn-primary">
          {saving ? 'Salvando...' : 'Salvar medição de espessura'}
        </button>
      </div>
    </div>
  );
}
