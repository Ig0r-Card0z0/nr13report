'use client';
import { useEffect, useRef, useState } from 'react';
import { fotosApi } from '@/lib/api';
import { Foto } from '@/types';
import toast from 'react-hot-toast';
import { X, Plus, ImageIcon } from 'lucide-react';

interface Props { equipamentoId: string; inspecaoId?: string; }

export function FotoRelatorio({ equipamentoId, inspecaoId }: Props) {
  const [fotos, setFotos] = useState<Foto[]>([]);
  const [lightbox, setLightbox] = useState<string | null>(null);
  const [uploading, setUploading] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);

  const load = () => fotosApi.listar(equipamentoId).then(setFotos);
  useEffect(() => { load(); }, [equipamentoId]);

  const upload = async (files: FileList | null) => {
    if (!files || !files.length) return;
    setUploading(true);
    try {
      for (const file of Array.from(files)) {
        const fd = new FormData();
        fd.append('file', file);
        fd.append('equipamentoId', equipamentoId);
        if (inspecaoId) fd.append('inspecaoId', inspecaoId);
        await fotosApi.upload(fd);
      }
      toast.success(`${files.length} foto(s) adicionada(s)!`);
      load();
    } catch { toast.error('Erro no upload.'); } finally {
      setUploading(false);
      if (fileRef.current) fileRef.current.value = '';
    }
  };

  const drop = (e: React.DragEvent) => {
    e.preventDefault();
    upload(e.dataTransfer.files);
  };

  const excluir = async (id: string) => {
    await fotosApi.excluir(id);
    toast.success('Foto removida.');
    load();
  };

  const legenda = async (id: string, val: string) => {
    await fotosApi.legenda(id, val);
  };

  return (
    <div>
      {/* Header */}
      <div className="flex items-center justify-between mb-4">
        <div className="text-sm text-gray-500">{fotos.length} foto(s) adicionada(s)</div>
        <button onClick={() => fileRef.current?.click()} disabled={uploading}
          className="btn btn-primary btn-sm">
          <Plus size={14} /> {uploading ? 'Enviando...' : 'Adicionar fotos'}
        </button>
        <input ref={fileRef} type="file" multiple accept="image/*" className="hidden"
          onChange={e => upload(e.target.files)} />
      </div>

      {/* Drop zone quando vazio */}
      {fotos.length === 0 && (
        <div onDrop={drop} onDragOver={e => e.preventDefault()}
          onClick={() => fileRef.current?.click()}
          className="border-2 border-dashed border-gray-300 rounded-xl p-12 text-center cursor-pointer
            hover:border-primary-400 hover:bg-primary-50 transition-colors group">
          <ImageIcon className="w-12 h-12 mx-auto mb-3 text-gray-200 group-hover:text-primary-300 transition-colors" />
          <div className="text-sm text-gray-500 group-hover:text-primary-600">
            Clique ou arraste imagens aqui
          </div>
          <div className="text-xs text-gray-400 mt-1">JPG, PNG, WEBP — múltiplas fotos suportadas</div>
        </div>
      )}

      {/* Grid de fotos */}
      {fotos.length > 0 && (
        <>
          <div onDrop={drop} onDragOver={e => e.preventDefault()}
            className="grid grid-cols-2 gap-4 md:grid-cols-3">
            {fotos.map(f => (
              <div key={f.id} className="bg-white border border-gray-200 rounded-xl overflow-hidden">
                <div className="relative">
                  <img
                    src={`/uploads/${f.filename}`}
                    alt={`Foto ${f.numero}`}
                    className="w-full h-40 object-cover cursor-pointer hover:opacity-90 transition-opacity"
                    onClick={() => setLightbox(`/uploads/${f.filename}`)}
                  />
                  <button onClick={() => excluir(f.id)}
                    className="absolute top-2 right-2 w-6 h-6 rounded-full bg-red-500 text-white
                      flex items-center justify-center hover:bg-red-600 transition-colors shadow">
                    <X size={12} />
                  </button>
                  <div className="absolute bottom-2 left-2 bg-black/50 text-white text-xs px-2 py-0.5 rounded">
                    Foto {f.numero}
                  </div>
                </div>
                <div className="p-2 border-t border-gray-100">
                  <input
                    className="w-full text-xs border-0 bg-transparent focus:outline-none
                      text-gray-700 placeholder-gray-300 font-medium"
                    defaultValue={f.legenda || ''}
                    placeholder="Legenda da foto..."
                    onBlur={e => legenda(f.id, e.target.value)}
                  />
                </div>
              </div>
            ))}

            {/* Botão de adicionar mais no grid */}
            <div onClick={() => fileRef.current?.click()}
              className="border-2 border-dashed border-gray-200 rounded-xl flex flex-col items-center
                justify-center h-40 cursor-pointer hover:border-primary-300 hover:bg-primary-50 transition-colors text-gray-300 hover:text-primary-400">
              <Plus size={24} />
              <span className="text-xs mt-1">Adicionar</span>
            </div>
          </div>
        </>
      )}

      {/* Lightbox */}
      {lightbox && (
        <div className="fixed inset-0 bg-black/90 z-50 flex items-center justify-center"
          onClick={() => setLightbox(null)}>
          <button className="absolute top-5 right-6 text-white hover:text-gray-300 transition-colors"
            onClick={() => setLightbox(null)}>
            <X size={28} />
          </button>
          <img src={lightbox} className="max-w-5xl max-h-[90vh] rounded-lg object-contain"
            onClick={e => e.stopPropagation()} />
        </div>
      )}
    </div>
  );
}
