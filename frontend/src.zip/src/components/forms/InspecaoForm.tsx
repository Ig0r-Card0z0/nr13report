'use client';
import { useState } from 'react';
import { inspecoesApi } from '@/lib/api';
import toast from 'react-hot-toast';

interface Props {
  equipamentoId: string;
  pmtaAtual?: number;
  onSaved: () => void;
}

const TIPOS = ['Externa', 'Interna', 'Interna e Externa'];
const RESULTADOS = ['Apto', 'Inapto', 'Apto com restrições'];

export function InspecaoForm({ equipamentoId, pmtaAtual, onSaved }: Props) {
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({
    data: '', tipo: 'Externa', resultado: 'Apto',
    phNome: '', phCrea: '', art: '',
    pmtaConfirmada: pmtaAtual?.toString() || '',
    proxExterno: '', proxInterno: '', observacoes: '',
  });

  const set = (k: string) => (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) =>
    setForm(f => ({ ...f, [k]: e.target.value }));

  const salvar = async () => {
    if (!form.data) { toast.error('Informe a data da inspeção.'); return; }
    setSaving(true);
    try {
      await inspecoesApi.criar({
        equipamentoId,
        data: form.data,
        tipo: form.tipo,
        resultado: form.resultado,
        phNome: form.phNome || undefined,
        phCrea: form.phCrea || undefined,
        art: form.art || undefined,
        pmtaConfirmada: form.pmtaConfirmada ? parseFloat(form.pmtaConfirmada) : undefined,
        proxExterno: form.proxExterno || undefined,
        proxInterno: form.proxInterno || undefined,
        observacoes: form.observacoes || undefined,
      });
      toast.success('Inspeção registrada!');
      setForm({ data:'', tipo:'Externa', resultado:'Apto', phNome:'', phCrea:'', art:'',
        pmtaConfirmada: pmtaAtual?.toString() || '', proxExterno:'', proxInterno:'', observacoes:'' });
      onSaved();
    } catch (err: any) {
      const msg = err?.response?.data?.message || err?.message || 'Erro ao salvar inspeção.';
      toast.error(String(msg));
    } finally { setSaving(false); }
  };

  return (
    <div className="bg-gray-50 border border-gray-200 rounded-xl p-5 mb-5">
      <h3 className="text-sm font-semibold text-gray-700 mb-4">Registrar nova inspeção</h3>

      <div className="grid grid-cols-3 gap-3 mb-3">
        <div>
          <label className="label">Data da inspeção *</label>
          <input className="input" type="date" value={form.data} onChange={set('data')} />
        </div>
        <div>
          <label className="label">Tipo</label>
          <select className="input" value={form.tipo} onChange={set('tipo')}>
            {TIPOS.map(t => <option key={t}>{t}</option>)}
          </select>
        </div>
        <div>
          <label className="label">Resultado</label>
          <select className="input" value={form.resultado} onChange={set('resultado')}>
            {RESULTADOS.map(r => <option key={r}>{r}</option>)}
          </select>
        </div>
        <div>
          <label className="label">PH responsável</label>
          <input className="input" value={form.phNome} onChange={set('phNome')} placeholder="Nome completo" />
        </div>
        <div>
          <label className="label">CREA</label>
          <input className="input" value={form.phCrea} onChange={set('phCrea')} placeholder="000000000-0" />
        </div>
        <div>
          <label className="label">ART</label>
          <input className="input" value={form.art} onChange={set('art')} placeholder="AM00000000000" />
        </div>
        <div>
          <label className="label">PMTA confirmada (bar)</label>
          <input className="input" type="number" step="0.1" value={form.pmtaConfirmada} onChange={set('pmtaConfirmada')} />
        </div>
        <div>
          <label className="label">Próx. exame externo</label>
          <input className="input" type="date" value={form.proxExterno} onChange={set('proxExterno')} />
        </div>
        <div>
          <label className="label">Próx. exame interno</label>
          <input className="input" type="date" value={form.proxInterno} onChange={set('proxInterno')} />
        </div>
      </div>

      <div className="mb-4">
        <label className="label">Observações / Recomendações do PH</label>
        <textarea className="input" rows={3} value={form.observacoes} onChange={set('observacoes')}
          placeholder="Descreva as recomendações, condições observadas, anomalias encontradas..." />
      </div>

      <div className="flex justify-end">
        <button onClick={salvar} disabled={saving} className="btn btn-primary">
          {saving ? 'Salvando...' : 'Registrar inspeção'}
        </button>
      </div>
    </div>
  );
}
