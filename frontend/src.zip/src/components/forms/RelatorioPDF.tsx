'use client';
import { Equipamento, Inspecao, Foto, MedicaoEspessura } from '@/types';
import { relatoriosApi } from '@/lib/api';
import { fmtData } from '@/lib/utils';
import { Download, FileText, CheckCircle } from 'lucide-react';

interface Props {
  equipamento: Equipamento;
  inspecoes: Inspecao[];
  fotos: Foto[];
  medicao: MedicaoEspessura | null;
}

export function RelatorioPDF({ equipamento: eq, inspecoes, fotos, medicao }: Props) {
  const ultima = inspecoes[0];

  const itens = [
    { label: 'Identificação do equipamento', ok: !!eq.tag },
    { label: 'Parâmetros operacionais', ok: !!(eq.volume && eq.pmta) },
    { label: 'Categoria NR-13 calculada', ok: !!eq.categoria },
    { label: 'Dados da empresa usuária', ok: !!eq.cliente_nome },
    { label: 'Prazos de inspeção NR-13', ok: !!(eq.prox_externo || eq.prox_interno) },
    { label: 'Histórico de inspeções', ok: inspecoes.length > 0 },
    { label: 'Profissional Habilitado (PH)', ok: !!(ultima?.ph_nome) },
    { label: 'Tabela de medição de espessura', ok: !!(medicao?.pontos?.length) },
    { label: 'Relatório fotográfico', ok: fotos.length > 0 },
  ];

  const prontos = itens.filter(i => i.ok).length;
  const pct = Math.round((prontos / itens.length) * 100);

  return (
    <div>
      {/* Checklist de completude */}
      <div className="bg-white border border-gray-200 rounded-xl p-5 mb-5">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-sm font-semibold text-gray-700">Completude do relatório</h3>
          <span className="text-lg font-bold text-primary-700">{pct}%</span>
        </div>
        <div className="w-full bg-gray-100 rounded-full h-2 mb-4">
          <div className="bg-primary-700 h-2 rounded-full transition-all" style={{ width: `${pct}%` }} />
        </div>
        <div className="grid grid-cols-2 gap-2">
          {itens.map(({ label, ok }) => (
            <div key={label} className="flex items-center gap-2 text-sm">
              <CheckCircle className={ok ? 'text-green-500 w-4 h-4 flex-shrink-0' : 'text-gray-200 w-4 h-4 flex-shrink-0'} />
              <span className={ok ? 'text-gray-700' : 'text-gray-400'}>{label}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Resumo */}
      <div className="grid grid-cols-3 gap-3 mb-5 text-center">
        {[
          { label: 'Inspeções', val: inspecoes.length },
          { label: 'Fotos', val: fotos.length },
          { label: 'Pontos ME', val: medicao?.pontos?.length || 0 },
        ].map(({ label, val }) => (
          <div key={label} className="bg-gray-50 rounded-lg p-3">
            <div className="text-2xl font-bold text-gray-900">{val}</div>
            <div className="text-xs text-gray-500">{label}</div>
          </div>
        ))}
      </div>

      {/* Botão principal */}
      <div className="bg-white border border-gray-200 rounded-xl p-8 text-center">
        <FileText className="w-14 h-14 mx-auto mb-4 text-primary-700" />
        <h3 className="text-lg font-semibold text-gray-900 mb-2">
          Gerar R.I.S.E. — Relatório de Inspeção de Segurança
        </h3>
        <p className="text-sm text-gray-500 mb-2">
          {eq.tag} — {eq.tipo} | {eq.cliente_nome}
        </p>
        {ultima && (
          <p className="text-xs text-gray-400 mb-6">
            Última inspeção: {fmtData(ultima.data)} | {ultima.resultado}
            {ultima.ph_nome ? ` | PH: ${ultima.ph_nome}` : ''}
          </p>
        )}

        <a href={relatoriosApi.urlPDF(eq.id)} target="_blank" rel="noopener noreferrer"
          className="btn btn-primary px-10 py-3 text-base inline-flex items-center gap-3">
          <Download size={20} />
          Baixar relatório em PDF
        </a>

        <p className="text-xs text-gray-400 mt-4">
          O arquivo PDF será gerado e baixado automaticamente pelo navegador.
        </p>
      </div>

      {/* O que está incluído */}
      <div className="mt-5 bg-white border border-gray-200 rounded-xl p-5">
        <div className="text-xs font-semibold text-gray-500 uppercase tracking-wide mb-3">Seções do relatório</div>
        <div className="grid grid-cols-2 gap-1.5 text-sm text-gray-600">
          {[
            '1 — Identificação do equipamento',
            '2 — Parâmetros operacionais',
            '3 — Empresa usuária',
            '4 — Prazos de inspeção NR-13',
            '5 — Histórico de inspeções',
            '6 — Medição de espessura por ultrassom',
            '7 — Relatório fotográfico',
            '8 — Conclusão e assinatura do PH',
          ].map(s => <div key={s} className="flex items-center gap-2"><CheckCircle size={13} className="text-green-400 flex-shrink-0" />{s}</div>)}
        </div>
      </div>
    </div>
  );
}
