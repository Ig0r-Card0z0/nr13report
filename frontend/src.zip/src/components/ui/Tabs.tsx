'use client';
import clsx from 'clsx';

interface Tab { id: string; label: string; icon?: React.ElementType; badge?: number; }

interface Props {
  tabs: Tab[];
  active: string;
  onChange: (id: string) => void;
}

export function Tabs({ tabs, active, onChange }: Props) {
  return (
    <div className="flex border-b border-gray-200 mb-5 overflow-x-auto">
      {tabs.map(({ id, label, icon: Icon, badge }) => (
        <button key={id} onClick={() => onChange(id)}
          className={clsx(
            'flex items-center gap-2 px-4 py-2.5 text-sm border-b-2 -mb-px transition-colors whitespace-nowrap',
            active === id
              ? 'border-primary-700 text-primary-700 font-semibold'
              : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
          )}>
          {Icon && <Icon size={14} />}
          {label}
          {badge !== undefined && badge > 0 && (
            <span className="ml-1 bg-gray-100 text-gray-600 text-xs font-semibold rounded-full px-1.5 py-0.5 leading-none">
              {badge}
            </span>
          )}
        </button>
      ))}
    </div>
  );
}
