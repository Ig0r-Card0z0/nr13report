'use client';
import { useEffect, useState } from 'react';
import { equipamentosApi, inspecoesApi, fotosApi, meApi, relatoriosApi } from '@/lib/api';
import { Equipamento, Inspecao, Foto, MedicaoEspessura } from '@/types';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import toast from 'react-hot-toast';
import { Pencil, Trash2, ClipboardList, Image, Activity, FileText, Download } from 'lucide-react';
import { fmtData } from '@/lib/utils';
import { PageHeader } from '@/components/ui/PageHeader';
import { Tabs } from '@/components/ui/Tabs';
import { VencBadge } from '@/components/ui/VencBadge';
import { Badge } from '@/components/ui/Badge';
import { PageLoading } from '@/components/ui/Loading';
import { ConfirmDialog } from '@/components/ui/ConfirmDialog';
import { InspecaoForm } from '@/components/forms/InspecaoForm';
import { FotoRelatorio } from '@/components/forms/FotoRelatorio';
import { MedicaoEspessuraForm } from '@/components/forms/MedicaoEspessuraForm';
import { RelatorioPDF } from '@/components/forms/RelatorioPDF';

export default function DetalheEquipamentoPage({ params }: { params: { id: string } }) {
  const router = useRouter();
  const eqId = params.id;
  const [eq, setEq] = useState<Equipamento | null>(null);
  const [inspecoes, setInspecoes] = useState<Inspecao[]>([]);
  const [fotos, setFotos] = useState<Foto[]>([]);
  const [medicao, setMedicao] = useState<MedicaoEspessura | null>(null);
  const [tab, setTab] = useState('insp');

  const loadEq    = () => equipamentosApi.buscar(eqId).then(setEq);
  const loadInsp  = () => inspecoesApi.listar(eqId).then(setInspecoes);
  const loadFotos = () => fotosApi.listar(eqId).then(setFotos);
  const loadMe    = () => meApi.listar(eqId).then(r => setMedicao(r[0] || null));

  useEffect(() => { loadEq(); loadInsp(); loadFotos(); loadMe(); }, [eqId]);

  const excluirEq = async () => {
    await equipamentosApi.excluir(eqId);
    toast.success('Equipamento excluído.');
    router.push(eq?.cliente_id ? `/clientes/${eq.cliente_id}` : '/equipamentos');
  };

  const excluirInsp = async (id: string) => {
    await inspecoesApi.excluir(id);
    toast.success('Inspeção removida.');
    loadInsp();
  };

  if (!eq) return <PageLoading />;

  const prazosNR: Record<string, { ext: string; int: string; hid: string }> = {
    I:   { ext: '40 anos', int: '40 anos', hid: '40 anos' },
    II:  { ext: '12 anos', int: '12 anos', hid: '20 anos' },
    III: { ext: '8 anos',  int: '8 anos',  hid: '20 anos' },
    IV:  { ext: '4 anos',  int: '8 anos',  hid: '20 anos' },
    V:   { ext: '2 anos',  int: '4 anos',  hid: '10 anos' },
  };
  const pnr = prazosNR[eq.categoria || ''] || { ext: '—', int: '—', hid: '—' };

  const TABS = [
    { id: 'insp', label: 'Inspecoes',           icon: ClipboardList, badge: inspecoes.length },
    { id: 'foto', label: 'Rel. Fotografico',    icon: Image,         badge: fotos.length },
    { id: 'me',   label: 'Medicao Espessura',   icon: Activity,      badge: medicao?.pontos?.length },
    { id: 'rel',  label: 'Relatorio PDF',       icon: FileText },
  ];

  return (
    <div>
      <PageHeader
        title={eq.tag + ' — ' + eq.tipo}
        breadcrumbs={[
          { label: 'Clientes', href: '/clientes' },
          { label: eq.cliente_nome || 'Cliente', href: eq.cliente_id ? '/clientes/' + eq.cliente_id : undefined },
          { label: eq.tag },
        ]}
        back={eq.cliente_id ? '/clientes/' + eq.cliente_id : '/equipamentos'}
        actions={
          <>
            <a href={relatoriosApi.urlPDF(eqId)} target="_blank" rel="noopener noreferrer" className="btn btn-sm btn-primary">
              <Download size={13} /> Exportar PDF
            </a>
            <Link href={'/equipamentos/' + eqId + '/editar'} className="btn btn-sm">
              <Pencil size={13} /> Editar
            </Link>
            <ConfirmDialog
              title="Excluir equipamento"
              message={'Excluir "' + eq.tag + '"? Todas as inspecoes, fotos e medicoes serao removidas.'}
              onConfirm={excluirEq}
              trigger={open => (
                <button onClick={open} className="btn btn-sm btn-danger"><Trash2 size={13} /></button>
              )}
            />
          </>
        }
      />

      <div className="card mb-5">
        <div className="flex items-center gap-2 mb-4">
          {eq.categoria && <Badge variant="info">Cat. {eq.categoria}</Badge>}
          {eq.grupo_risco && <Badge variant="gray">{eq.grupo_risco}</Badge>}
          {eq.classe_fluido && <Badge variant="gray">Classe {eq.classe_fluido}</Badge>}
        </div>
        <div className="grid grid-cols-3 gap-3 text-sm mb-5">
          {[
            ['Fabricante',    eq.fabricante],
            ['N Serie',       eq.serie],
            ['Ano',           eq.ano],
            ['Volume',        eq.volume           ? eq.volume + ' m3'          : null],
            ['PMTA',          eq.pmta             ? eq.pmta + ' bar'           : null],
            ['P. Operacao',   eq.pressao_operacao ? eq.pressao_operacao + ' kgf/cm2' : null],
            ['Fluido',        eq.fluido],
            ['Temp. Projeto', eq.temperatura_projeto ? eq.temperatura_projeto + ' C' : null],
            ['Metal de base', eq.metal_base],
            ['Posicao',       eq.posicao],
            ['Cod. Projeto',  eq.codigo_projeto],
            ['Local instal.', eq.local_instalacao],
          ].filter(([, v]) => v).map(([l, v]) => (
            <div key={l as string}>
              <div className="text-xs text-gray-400 mb-0.5">{l}</div>
              <div className="font-medium text-gray-900">{v}</div>
            </div>
          ))}
        </div>

        <hr className="border-gray-100 mb-4" />
        <div className="text-xs font-semibold text-gray-500 uppercase tracking-wide mb-3">Prazos de inspecao</div>
        <table className="w-full text-sm">
          <thead>
            <tr className="bg-gray-50">
              {['Tipo','Prazo max. NR-13','Proxima prevista (PH)','Status'].map(h => (
                <th key={h} className="text-left text-xs font-semibold text-gray-500 uppercase tracking-wide px-3 py-2">{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {[
              ['Exame externo',      pnr.ext, eq.prox_externo],
              ['Exame interno',      pnr.int, eq.prox_interno],
              ['Teste hidrostatico', pnr.hid, eq.prox_hidro],
            ].map(([tipo, nr, dt]) => (
              <tr key={tipo as string} className="border-t border-gray-100">
                <td className="px-3 py-2">{tipo}</td>
                <td className="px-3 py-2 text-gray-500">{nr}</td>
                <td className="px-3 py-2 font-medium">{fmtData(dt as string)}</td>
                <td className="px-3 py-2"><VencBadge dt={dt as string} /></td>
              </tr>
            ))}
          </tbody>
        </table>
        {eq.dt_ultima_insp && (
          <div className="text-xs text-gray-400 mt-3 pt-3 border-t border-gray-100">
            Ultima inspecao: <span className="font-medium text-gray-600">{fmtData(eq.dt_ultima_insp)}</span>
            {eq.tipo_ultima_insp ? ' — ' + eq.tipo_ultima_insp : ''}
            {eq.art_ultima_insp  ? ' | ART: ' + eq.art_ultima_insp : ''}
          </div>
        )}
      </div>

      <Tabs tabs={TABS} active={tab} onChange={setTab} />

      {tab === 'insp' && (
        <div>
          <InspecaoForm equipamentoId={eqId} pmtaAtual={eq.pmta} onSaved={() => { loadInsp(); loadEq(); }} />
          <h3 className="text-sm font-semibold text-gray-700 mb-3">Historico ({inspecoes.length})</h3>
          {inspecoes.length === 0
            ? <div className="card text-center py-8 text-gray-400 text-sm">Nenhuma inspecao registrada.</div>
            : inspecoes.map(ins => {
                const cor = ins.resultado === 'Apto' ? 'success' : ins.resultado === 'Inapto' ? 'danger' : 'warning';
                return (
                  <div key={ins.id} className="card mb-2 flex items-start gap-4">
                    <div className="text-sm font-semibold text-gray-700 w-24 flex-shrink-0">{fmtData(ins.data)}</div>
                    <div className="flex-1 text-sm text-gray-600">
                      <div className="font-medium text-gray-800">{ins.tipo}</div>
                      <div className="text-xs mt-0.5">PH: {ins.ph_nome||'—'} · ART: {ins.art||'—'}{ins.pmta_confirmada?' · PMTA: '+ins.pmta_confirmada+' bar':''}</div>
                      {ins.observacoes && <div className="mt-1 bg-gray-50 rounded p-2 text-xs">{ins.observacoes}</div>}
                    </div>
                    <Badge variant={cor as any}>{ins.resultado}</Badge>
                    <ConfirmDialog title="Excluir inspecao" message="Esta acao nao pode ser desfeita."
                      onConfirm={() => excluirInsp(ins.id)}
                      trigger={open => <button onClick={open} className="btn btn-xs btn-danger"><Trash2 size={11}/></button>}/>
                  </div>
                );
              })
          }
        </div>
      )}

      {tab === 'foto' && <FotoRelatorio equipamentoId={eqId} />}
      {tab === 'me'   && <MedicaoEspessuraForm equipamentoId={eqId} metalBase={eq.metal_base} onSaved={loadMe} />}
      {tab === 'rel'  && <RelatorioPDF equipamento={eq} inspecoes={inspecoes} fotos={fotos} medicao={medicao} />}
    </div>
  );
}
